jQuery(document).ready(function($){
  $('.site-header .menu-principal .menu').slicknav({
    label: '',
    appendTo: '.site-header',
  });
});
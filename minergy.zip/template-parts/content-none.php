<article class="NotFound">
  <h2><?php _e('Contenido inexistente', 'minergy'); ?></h2>
  <p>
    <?php _e('Realiza una búsqueda para encontrar lo que deseas', 'minergy'); ?>
  </p>
</article>
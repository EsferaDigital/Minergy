  <footer class="site-footer">
    <div class="contenedor">
      <div class="contenido-footer">
        <p>Únete a nuestra red para innovar, desde el sector minero energético</p>
        <div class="sociales-footer">
          <div class="sociales-titulo">
            <h3>SÍGUENOS</h3>
          </div>
          <div class="sociales-link">
            <a href="https://twitter.com/Minergy_Connect" target="_blank" rel="noopener noreferrer">
              <i class="fab fa-twitter"></i>
            </a>
            <a href="https://www.instagram.com/minergy_connect/?hl=es-la">
              <i class="fab fa-instagram"></i>
            </a>
            <a href="https://www.linkedin.com/company/minergy-connect/">
              <i class="fab fa-linkedin-in"></i>
            </a>
            <a href="https://www.facebook.com/Minergy-Connect-119554063221770">
              <i class="fab fa-facebook-f"></i>
            </a>
          </div>
          
          <a href="http://" target="_blank" rel="noopener noreferrer"></a>
        </div>
      </div>
      <section class="footer-menu">
        <ul>
          <li>
            <a href="https://com-unidad.pe/main/quienes-somos" target="_blank">Quiénes somos</a>
          </li>
          <li>
            <a href="https://com-unidad.pe/main/terminos" target="_blank">Términos y condiciones</a>
          </li>
          <li>
            <a href="https://com-unidad.pe/main/objetivos-desarrollo-sostenible" target="_blank">Objetivos del desarrollo sostenible</a>
          </li>
          <li>
            <a href="https://com-unidad.pe/main/contacto" target="_blank">Contacto</a>
          </li>
        </ul>
      </section>
      <div class="Card-copy">
        <p class="Small-text">Copyright &copy; <?php echo date('Y');?> Minergy Connect.</p>
        <p class="Small-text">Todos los derechos reservados.</p>
      </div>
      <div class="Box-creditos">
        <p class="Small-text">Desarrollado por<a class="Link-text-creditos" href="https://esferadigital.cl" target="_blank"> esferadigital.cl</a></p>
      </div>
    </div>
  </footer>
  <?php wp_footer();?>
</body>
</html>